package com.example.to_do_list_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
